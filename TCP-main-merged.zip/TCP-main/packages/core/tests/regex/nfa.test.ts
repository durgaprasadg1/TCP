import { describe, expect, it } from 'vitest';
import { parseRegex } from '../../src/regex/parser';
import { buildNfa, epsilonClosure, move, EPSILON } from '../../src/regex/nfa';

describe('buildNfa - Thompson construction', () => {
  it('builds a two-state fragment for a single literal', () => {
    const nfa = buildNfa(parseRegex('a'));
    expect(nfa.states.length).toBe(2);
    expect(nfa.transitions).toEqual([{ from: nfa.start, symbol: 'a', to: nfa.accept }]);
  });

  it('chains fragments with an epsilon transition for concatenation', () => {
    const nfa = buildNfa(parseRegex('ab'));
    // 4 states: a-start, a-accept, b-start, b-accept
    expect(nfa.states.length).toBe(4);
    const epsilons = nfa.transitions.filter((t) => t.symbol === EPSILON);
    expect(epsilons.length).toBe(1);
  });

  it('creates a branch/join structure for union', () => {
    const nfa = buildNfa(parseRegex('a|b'));
    // new start + new accept + 2 fragments (2 states each) = 6
    expect(nfa.states.length).toBe(6);
    const fromStart = nfa.transitions.filter((t) => t.from === nfa.start && t.symbol === EPSILON);
    expect(fromStart.length).toBe(2);
  });

  it('creates loop-back epsilon transitions for star', () => {
    const nfa = buildNfa(parseRegex('a*'));
    // new start + new accept + inner fragment (2) = 4
    expect(nfa.states.length).toBe(4);
    // start should reach accept directly via epsilon (zero repetitions)
    const closure = epsilonClosure(nfa, [nfa.start]);
    expect(closure.has(nfa.accept)).toBe(true);
  });

  it('only ever has a single accept state (Thompson invariant)', () => {
    for (const re of ['a', 'ab', 'a|b', 'a*', '(a|b)*c', 'ab|cd*']) {
      const nfa = buildNfa(parseRegex(re));
      // accept state should have no outgoing transitions
      const outgoing = nfa.transitions.filter((t) => t.from === nfa.accept);
      expect(outgoing.length).toBe(0);
    }
  });
});

describe('epsilonClosure', () => {
  it('includes the state itself', () => {
    const nfa = buildNfa(parseRegex('a'));
    const closure = epsilonClosure(nfa, [nfa.start]);
    expect(closure.has(nfa.start)).toBe(true);
  });

  it('follows chains of epsilon transitions transitively', () => {
    const nfa = buildNfa(parseRegex('a*b*'));
    const closure = epsilonClosure(nfa, [nfa.start]);
    // From the start of a*b*, epsilon-closure should reach the start
    // of the b* fragment too (zero 'a's is valid).
    expect(closure.size).toBeGreaterThan(1);
  });
});

describe('move', () => {
  it('returns states reachable by exactly one literal symbol', () => {
    const nfa = buildNfa(parseRegex('a'));
    const moved = move(nfa, [nfa.start], 'a');
    expect(moved.has(nfa.accept)).toBe(true);
    expect(moved.size).toBe(1);
  });

  it('returns an empty set for a symbol with no matching transition', () => {
    const nfa = buildNfa(parseRegex('a'));
    const moved = move(nfa, [nfa.start], 'b');
    expect(moved.size).toBe(0);
  });
});
