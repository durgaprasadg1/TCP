import { makeError } from './errors';

export type TokenType = 'CHAR' | 'PIPE' | 'STAR' | 'LPAREN' | 'RPAREN' | 'EOF';

export interface Token {
  type: TokenType;
  /** The literal character for CHAR tokens; the symbol itself otherwise. */
  value: string;
  /** 0-indexed offset into the source regex string. */
  position: number;
}

/**
 * Supported alphabet: ASCII letters and digits only.
 * Anything else (whitespace, punctuation, unicode, `\`, `+`, `?`, `.`,
 * character classes, etc.) is explicitly unsupported in this MVP and
 * is rejected with a structured error rather than silently accepted.
 */
function isLiteralChar(ch: string): boolean {
  return /^[A-Za-z0-9]$/.test(ch);
}

export function tokenize(source: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  while (i < source.length) {
    const ch = source.charAt(i);

    if (ch === '|') {
      tokens.push({ type: 'PIPE', value: '|', position: i });
      i++;
      continue;
    }
    if (ch === '*') {
      tokens.push({ type: 'STAR', value: '*', position: i });
      i++;
      continue;
    }
    if (ch === '(') {
      tokens.push({ type: 'LPAREN', value: '(', position: i });
      i++;
      continue;
    }
    if (ch === ')') {
      tokens.push({ type: 'RPAREN', value: ')', position: i });
      i++;
      continue;
    }
    if (ch === '\\') {
      throw makeError('UNSUPPORTED_ESCAPE', `Escape sequences are not supported in this MVP (found '\\' at position ${i}).`, i);
    }
    if (isLiteralChar(ch)) {
      tokens.push({ type: 'CHAR', value: ch, position: i });
      i++;
      continue;
    }

    // Whitespace and any other symbol (+, ?, ., [, ], ^, $, etc.)
    const label = ch === ' ' ? 'whitespace' : `'${ch}'`;
    throw makeError(
      'UNEXPECTED_CHARACTER',
      `Unexpected character ${label} at position ${i}. Only letters, digits, '|', '*', '(' and ')' are supported.`,
      i,
    );
  }

  tokens.push({ type: 'EOF', value: '', position: source.length });
  return tokens;
}
