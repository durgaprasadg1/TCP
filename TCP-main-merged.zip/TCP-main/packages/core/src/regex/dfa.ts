import { epsilonClosure, move, nfaAlphabet, type Nfa, type StateId } from './nfa';

export type DfaStateId = number;

export interface DfaTransition {
  from: DfaStateId;
  symbol: string;
  to: DfaStateId;
}

export interface DfaState {
  id: DfaStateId;
  /** The underlying set of NFA states this DFA state represents. */
  nfaStates: StateId[];
  isAccept: boolean;
}

export interface Dfa {
  states: DfaState[];
  start: DfaStateId;
  alphabet: string[];
  transitions: DfaTransition[];
  stateLabel: (id: DfaStateId) => string;
}

/** Deterministic key for a set of NFA state ids, used to dedupe DFA states. */
function setKey(set: Set<StateId>): string {
  return [...set].sort((a, b) => a - b).join(',');
}

/**
 * Subset construction: converts an NFA into an equivalent DFA.
 * DFA state IDs are assigned in the deterministic order the subsets
 * are first discovered (BFS from the start state, alphabet iterated
 * in sorted order), so the same NFA always yields the same DFA
 * numbering.
 */
export function buildDfa(nfa: Nfa): Dfa {
  const alphabet = nfaAlphabet(nfa);
  const startSet = epsilonClosure(nfa, [nfa.start]);
  const startKey = setKey(startSet);

  const keyToId = new Map<string, DfaStateId>();
  const states: DfaState[] = [];
  const transitions: DfaTransition[] = [];

  let nextId = 0;
  function getOrCreateState(set: Set<StateId>): DfaStateId {
    const key = setKey(set);
    const existing = keyToId.get(key);
    if (existing !== undefined) return existing;
    const id = nextId++;
    keyToId.set(key, id);
    states.push({
      id,
      nfaStates: [...set].sort((a, b) => a - b),
      isAccept: set.has(nfa.accept),
    });
    return id;
  }

  const startId = getOrCreateState(startSet);
  void startKey;

  const queue: Array<{ id: DfaStateId; set: Set<StateId> }> = [{ id: startId, set: startSet }];
  const visited = new Set<DfaStateId>([startId]);

  while (queue.length > 0) {
    const { id, set } = queue.shift()!;
    for (const symbol of alphabet) {
      const moved = move(nfa, set, symbol);
      if (moved.size === 0) continue; // no transition on this symbol (implicit dead state)
      const closure = epsilonClosure(nfa, moved);
      const targetId = getOrCreateState(closure);
      transitions.push({ from: id, symbol, to: targetId });
      if (!visited.has(targetId)) {
        visited.add(targetId);
        queue.push({ id: targetId, set: closure });
      }
    }
  }

  return {
    states,
    start: startId,
    alphabet,
    transitions,
    stateLabel: (id) => `D${id}`,
  };
}

/** Look up the DFA transition target, or undefined if none exists (dead/reject). */
export function dfaStep(dfa: Dfa, from: DfaStateId, symbol: string): DfaStateId | undefined {
  const t = dfa.transitions.find((tr) => tr.from === from && tr.symbol === symbol);
  return t?.to;
}
