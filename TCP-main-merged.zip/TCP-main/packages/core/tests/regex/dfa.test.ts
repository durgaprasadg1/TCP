import { describe, expect, it } from 'vitest';
import { parseRegex } from '../../src/regex/parser';
import { buildNfa } from '../../src/regex/nfa';
import { buildDfa, dfaStep } from '../../src/regex/dfa';

function dfaFor(re: string) {
  return buildDfa(buildNfa(parseRegex(re)));
}

describe('buildDfa - subset construction', () => {
  it('produces a DFA with no epsilon transitions and exactly one target per (state, symbol)', () => {
    const dfa = dfaFor('(a|b)*abb');
    const seen = new Set<string>();
    for (const t of dfa.transitions) {
      expect(t.symbol).not.toBe('ε');
      const key = `${t.from}|${t.symbol}`;
      expect(seen.has(key)).toBe(false);
      seen.add(key);
    }
  });

  it('start state includes epsilon-closure of the NFA start', () => {
    const dfa = dfaFor('a*b');
    const start = dfa.states.find((s) => s.id === dfa.start)!;
    expect(start.nfaStates.length).toBeGreaterThan(0);
  });

  it('marks a DFA state accepting iff its subset contains the NFA accept state', () => {
    const nfa = buildNfa(parseRegex('a'));
    const dfa = buildDfa(nfa);
    const afterA = dfaStep(dfa, dfa.start, 'a')!;
    const stateAfterA = dfa.states.find((s) => s.id === afterA)!;
    expect(stateAfterA.isAccept).toBe(true);
    expect(stateAfterA.nfaStates).toContain(nfa.accept);
  });

  it('computes a correct (unminimized) DFA for a simple star regex', () => {
    const dfa = dfaFor('a*');
    // Subset construction does not minimize: Thompson's a* NFA yields two
    // distinct-but-equivalent subsets (start-closure vs post-'a'-closure),
    // both accepting, with 'a' looping the second one to itself.
    expect(dfa.states.length).toBe(2);
    expect(dfa.states.every((s) => s.isAccept)).toBe(true);
    const afterA = dfaStep(dfa, dfa.start, 'a')!;
    expect(afterA).toBeDefined();
    const loopedAgain = dfaStep(dfa, afterA, 'a');
    expect(loopedAgain).toBe(afterA);
  });

  it('has no transition (dead/implicit) for a symbol outside the alphabet', () => {
    const dfa = dfaFor('a');
    expect(dfaStep(dfa, dfa.start, 'z')).toBeUndefined();
  });
});
