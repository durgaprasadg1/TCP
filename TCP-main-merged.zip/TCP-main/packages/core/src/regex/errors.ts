/**
 * Structured error type used across the lexer/parser.
 *
 * We deliberately avoid throwing raw `Error` objects for expected,
 * user-facing failures (malformed regex input) so the UI can render
 * a precise, actionable message with a caret pointing at the
 * offending character.
 */
export interface RegexError {
  /** Short machine-friendly category, useful for tests. */
  code:
    | 'EMPTY_REGEX'
    | 'UNEXPECTED_CHARACTER'
    | 'UNSUPPORTED_ESCAPE'
    | 'UNBALANCED_PAREN_OPEN'
    | 'UNBALANCED_PAREN_CLOSE'
    | 'EMPTY_GROUP'
    | 'DANGLING_OPERATOR'
    | 'UNEXPECTED_TOKEN'
    | 'TRAILING_INPUT';
  /** Human-readable, displayed directly in the UI. */
  message: string;
  /** 0-indexed character offset into the original regex string. */
  position: number;
}

export class RegexSyntaxError extends Error {
  readonly regexError: RegexError;

  constructor(regexError: RegexError) {
    super(regexError.message);
    this.name = 'RegexSyntaxError';
    this.regexError = regexError;
  }
}

export function makeError(code: RegexError['code'], message: string, position: number): RegexSyntaxError {
  return new RegexSyntaxError({ code, message, position });
}
