/**
 * A small, dependency-free layered ("Sugiyama-lite") graph layout.
 *
 * Not a general-purpose graph layout algorithm — it is tuned for the
 * small, mostly-DAG-shaped automata this app produces (a handful to a
 * few dozen states). Nodes are placed into columns by BFS distance
 * from the start state; nodes unreachable from start (shouldn't
 * normally happen for these automata, but handled defensively) are
 * appended in a final column.
 */
export interface LayoutNode {
  id: number;
  x: number;
  y: number;
}

export interface LayoutEdge {
  from: number;
  to: number;
}

export interface GraphLayout {
  nodes: LayoutNode[];
  width: number;
  height: number;
}

const COLUMN_WIDTH = 150;
const ROW_HEIGHT = 90;
const PADDING_X = 70;
const PADDING_Y = 60;

export function layoutGraph(nodeIds: number[], edges: LayoutEdge[], startId: number): GraphLayout {
  const adjacency = new Map<number, number[]>();
  for (const id of nodeIds) adjacency.set(id, []);
  for (const e of edges) {
    if (e.from === e.to) continue; // self-loops don't affect layering
    adjacency.get(e.from)?.push(e.to);
  }

  const layer = new Map<number, number>();
  const queue: number[] = [startId];
  layer.set(startId, 0);
  while (queue.length > 0) {
    const current = queue.shift()!;
    const currentLayer = layer.get(current)!;
    for (const next of adjacency.get(current) ?? []) {
      if (!layer.has(next)) {
        layer.set(next, currentLayer + 1);
        queue.push(next);
      }
    }
  }

  // Any node not reached by BFS (disconnected/unreachable) goes in the
  // last column, defensively — this should not occur for automata
  // built from a single connected Thompson construction.
  let maxLayer = Math.max(0, ...[...layer.values()]);
  for (const id of nodeIds) {
    if (!layer.has(id)) {
      maxLayer += 1;
      layer.set(id, maxLayer);
    }
  }

  const byLayer = new Map<number, number[]>();
  for (const id of nodeIds) {
    const l = layer.get(id)!;
    if (!byLayer.has(l)) byLayer.set(l, []);
    byLayer.get(l)!.push(id);
  }
  for (const ids of byLayer.values()) ids.sort((a, b) => a - b);

  const maxRows = Math.max(1, ...[...byLayer.values()].map((v) => v.length));

  const nodes: LayoutNode[] = [];
  for (const [l, ids] of byLayer) {
    const columnHeight = ids.length * ROW_HEIGHT;
    const totalHeight = maxRows * ROW_HEIGHT;
    const offsetY = (totalHeight - columnHeight) / 2;
    ids.forEach((id, i) => {
      nodes.push({
        id,
        x: PADDING_X + l * COLUMN_WIDTH,
        y: PADDING_Y + offsetY + i * ROW_HEIGHT,
      });
    });
  }

  const width = PADDING_X * 2 + maxLayer * COLUMN_WIDTH;
  const height = PADDING_Y * 2 + (maxRows - 1) * ROW_HEIGHT;

  return { nodes, width: Math.max(width, 300), height: Math.max(height, 200) };
}
