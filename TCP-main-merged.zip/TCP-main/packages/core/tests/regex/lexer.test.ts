import { describe, expect, it } from 'vitest';
import { tokenize } from '../../src/regex/lexer';
import { RegexSyntaxError } from '../../src/regex/errors';

describe('tokenize', () => {
  it('tokenizes literals', () => {
    const tokens = tokenize('ab1');
    expect(tokens.map((t) => t.type)).toEqual(['CHAR', 'CHAR', 'CHAR', 'EOF']);
    expect(tokens.map((t) => t.value)).toEqual(['a', 'b', '1', '']);
  });

  it('tokenizes operators and parens', () => {
    const tokens = tokenize('a|b*(c)');
    expect(tokens.map((t) => t.type)).toEqual(['CHAR', 'PIPE', 'CHAR', 'STAR', 'LPAREN', 'CHAR', 'RPAREN', 'EOF']);
  });

  it('tracks positions', () => {
    const tokens = tokenize('a|b');
    expect(tokens[1]!.position).toBe(1);
    expect(tokens[2]!.position).toBe(2);
  });

  it('rejects whitespace', () => {
    expect(() => tokenize('a b')).toThrow(RegexSyntaxError);
    try {
      tokenize('a b');
    } catch (e) {
      expect((e as RegexSyntaxError).regexError.code).toBe('UNEXPECTED_CHARACTER');
      expect((e as RegexSyntaxError).regexError.position).toBe(1);
    }
  });

  it('rejects escape sequences', () => {
    try {
      tokenize('a\\b');
      expect.unreachable();
    } catch (e) {
      expect((e as RegexSyntaxError).regexError.code).toBe('UNSUPPORTED_ESCAPE');
    }
  });

  it('rejects unsupported symbols like + and .', () => {
    for (const bad of ['a+', 'a.', 'a?', '[a]', '^a', 'a$']) {
      expect(() => tokenize(bad)).toThrow(RegexSyntaxError);
    }
  });
});
