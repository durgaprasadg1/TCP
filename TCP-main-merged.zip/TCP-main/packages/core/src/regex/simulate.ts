import type { Dfa, DfaStateId } from './dfa';
import { dfaStep } from './dfa';
import type { Nfa, StateId } from './nfa';
import { epsilonClosure, move } from './nfa';

/** Sentinel DFA state id representing an implicit dead/trap state. */
export const DEAD_STATE = -1;

export interface DfaSimStep {
  /** 0-indexed step number; step 0 is the initial state before any input. */
  index: number;
  /** How many input characters have been consumed to reach this step. */
  position: number;
  stateId: DfaStateId;
  /** The character just consumed to reach this step (absent at step 0). */
  consumedChar?: string;
  isDead: boolean;
}

export interface DfaTrace {
  input: string;
  steps: DfaSimStep[];
  accepted: boolean;
  /** True if the input contains a character never seen in the regex. */
  hasOutOfAlphabetChar: boolean;
}

/**
 * Runs the DFA over `input` one character at a time, producing a full
 * step-by-step trace. Acceptance is evaluated only once the entire
 * input has been consumed (final step), not mid-way through.
 *
 * If the DFA has no transition for a character (either because the
 * symbol is outside the regex's alphabet, or the current state is a
 * true trap), the simulation moves into an explicit DEAD_STATE for
 * all remaining steps rather than throwing — so Next/Previous
 * navigation stays well-defined across the entire input.
 */
export function simulateDfa(dfa: Dfa, input: string): DfaTrace {
  const alphabetSet = new Set(dfa.alphabet);
  const hasOutOfAlphabetChar = [...input].some((ch) => !alphabetSet.has(ch));

  const steps: DfaSimStep[] = [{ index: 0, position: 0, stateId: dfa.start, isDead: false }];

  let current = dfa.start;
  let dead = false;

  for (let i = 0; i < input.length; i++) {
    const ch = input.charAt(i);
    if (!dead) {
      const next = dfaStep(dfa, current, ch);
      if (next === undefined) {
        dead = true;
        current = DEAD_STATE;
      } else {
        current = next;
      }
    }
    steps.push({
      index: i + 1,
      position: i + 1,
      stateId: current,
      consumedChar: ch,
      isDead: dead,
    });
  }

  // `steps` always holds at least the initial step, so the last element exists.
  const lastStep = steps[steps.length - 1] as DfaSimStep;
  const finalState = dfa.states.find((s) => s.id === lastStep.stateId);
  const accepted = !lastStep.isDead && finalState !== undefined && finalState.isAccept;

  return { input, steps, accepted, hasOutOfAlphabetChar };
}

export interface NfaSimStep {
  index: number;
  position: number;
  /** Epsilon-closed set of active NFA states at this step, sorted. */
  states: StateId[];
  consumedChar?: string;
}

export interface NfaTrace {
  input: string;
  steps: NfaSimStep[];
  accepted: boolean;
}

/**
 * Runs the NFA over `input` one character at a time, tracking the
 * full (epsilon-closed) set of active states at every step -
 * correctly handling nondeterministic branching without ever
 * enumerating individual paths.
 */
export function simulateNfa(nfa: Nfa, input: string): NfaTrace {
  const initial = epsilonClosure(nfa, [nfa.start]);
  const steps: NfaSimStep[] = [{ index: 0, position: 0, states: [...initial].sort((a, b) => a - b) }];

  let current = initial;
  for (let i = 0; i < input.length; i++) {
    const ch = input.charAt(i);
    const moved = move(nfa, current, ch);
    const closed = epsilonClosure(nfa, moved);
    current = closed;
    steps.push({
      index: i + 1,
      position: i + 1,
      states: [...closed].sort((a, b) => a - b),
      consumedChar: ch,
    });
  }

  const accepted = current.has(nfa.accept);
  return { input, steps, accepted };
}
