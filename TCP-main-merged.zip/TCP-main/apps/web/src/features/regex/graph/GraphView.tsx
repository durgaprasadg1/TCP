import { useMemo, useId } from 'react';
import { layoutGraph } from './layout';
import './graph.css';

export interface GraphNodeInput {
  id: number;
  label: string;
  isStart: boolean;
  isAccept: boolean;
}

export interface GraphEdgeInput {
  from: number;
  to: number;
  label: string;
  isEpsilon?: boolean;
}

export interface GraphViewProps {
  nodes: GraphNodeInput[];
  edges: GraphEdgeInput[];
  startId: number;
  /** Node ids to visually highlight (e.g. "currently active" during simulation). */
  highlightNodeIds?: ReadonlySet<number>;
  /** Edge keys ("from->to") to highlight, e.g. the transition just taken. */
  highlightEdgeKeys?: ReadonlySet<string>;
  ariaLabel: string;
  emptyMessage?: string;
}

const NODE_RADIUS = 22;

function edgeKey(from: number, to: number): string {
  return `${from}->${to}`;
}

/** Groups parallel edges between the same ordered pair into one labeled edge. */
function groupEdges(edges: GraphEdgeInput[]): GraphEdgeInput[] {
  const map = new Map<string, GraphEdgeInput>();
  for (const e of edges) {
    const key = edgeKey(e.from, e.to);
    const existing = map.get(key);
    if (existing) {
      const labels = existing.label.split(', ');
      if (!labels.includes(e.label)) {
        existing.label = [...labels, e.label].sort().join(', ');
      }
      existing.isEpsilon = existing.isEpsilon && e.isEpsilon;
    } else {
      map.set(key, { ...e });
    }
  }
  return [...map.values()];
}

export function GraphView({ nodes, edges, startId, highlightNodeIds, highlightEdgeKeys, ariaLabel, emptyMessage }: GraphViewProps) {
  // useId() can contain characters like ":" (React 18); keep the SVG marker id a plain token.
  const gradientId = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  const grouped = useMemo(() => groupEdges(edges), [edges]);

  const layout = useMemo(
    () =>
      layoutGraph(
        nodes.map((n) => n.id),
        grouped,
        startId,
      ),
    [nodes, grouped, startId],
  );

  const positionById = useMemo(() => {
    const m = new Map<number, { x: number; y: number }>();
    for (const n of layout.nodes) m.set(n.id, { x: n.x, y: n.y });
    return m;
  }, [layout]);

  const nodeById = useMemo(() => {
    const m = new Map<number, GraphNodeInput>();
    for (const n of nodes) m.set(n.id, n);
    return m;
  }, [nodes]);

  if (nodes.length === 0) {
    return (
      <div className="graph-empty" role="status">
        {emptyMessage ?? 'Nothing to display yet.'}
      </div>
    );
  }

  return (
    <div className="graph-scroll">
      <svg
        role="img"
        aria-label={ariaLabel}
        width={layout.width}
        height={layout.height}
        viewBox={`0 0 ${layout.width} ${layout.height}`}
        className="graph-svg"
      >
        <defs>
          <marker
            id={`arrow-${gradientId}`}
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" className="graph-arrowhead" />
          </marker>
          <marker
            id={`arrow-hl-${gradientId}`}
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" className="graph-arrowhead-highlight" />
          </marker>
        </defs>

        {/* Start-state pointer */}
        {(() => {
          const p = positionById.get(startId);
          if (!p) return null;
          const x0 = p.x - NODE_RADIUS - 28;
          return (
            <g>
              <line x1={x0} y1={p.y} x2={p.x - NODE_RADIUS - 2} y2={p.y} className="graph-edge" markerEnd={`url(#arrow-${gradientId})`} />
            </g>
          );
        })()}

        {grouped.map((e) => {
          const from = positionById.get(e.from);
          const to = positionById.get(e.to);
          if (!from || !to) return null;
          const key = edgeKey(e.from, e.to);
          const isHighlighted = highlightEdgeKeys?.has(key) ?? false;
          const hasReverse = grouped.some((o) => o.from === e.to && o.to === e.from);

          if (e.from === e.to) {
            // Self-loop, drawn as an arc above the node.
            const loopPath = `M ${from.x - 10} ${from.y - NODE_RADIUS} C ${from.x - 30} ${
              from.y - NODE_RADIUS - 45
            }, ${from.x + 30} ${from.y - NODE_RADIUS - 45}, ${from.x + 10} ${from.y - NODE_RADIUS}`;
            return (
              <g key={key}>
                <path
                  d={loopPath}
                  className={isHighlighted ? 'graph-edge-highlight' : 'graph-edge'}
                  markerEnd={`url(#${isHighlighted ? 'arrow-hl-' : 'arrow-'}${gradientId})`}
                  fill="none"
                />
                <text
                  x={from.x}
                  y={from.y - NODE_RADIUS - 48}
                  textAnchor="middle"
                  className={isHighlighted ? 'graph-edge-label-highlight' : 'graph-edge-label'}
                >
                  {e.label}
                </text>
              </g>
            );
          }

          const dx = to.x - from.x;
          const dy = to.y - from.y;
          const dist = Math.hypot(dx, dy) || 1;
          const ux = dx / dist;
          const uy = dy / dist;
          const startX = from.x + ux * NODE_RADIUS;
          const startY = from.y + uy * NODE_RADIUS;
          const endX = to.x - ux * NODE_RADIUS;
          const endY = to.y - uy * NODE_RADIUS;

          const midX = (startX + endX) / 2;
          const midY = (startY + endY) / 2;
          // Perpendicular offset so A->B and B->A don't overlap.
          const curve = hasReverse ? 18 : 0;
          const px = -uy * curve;
          const py = ux * curve;
          const ctrlX = midX + px;
          const ctrlY = midY + py;

          const path = curve ? `M ${startX} ${startY} Q ${ctrlX} ${ctrlY} ${endX} ${endY}` : `M ${startX} ${startY} L ${endX} ${endY}`;

          return (
            <g key={key}>
              <path
                d={path}
                className={isHighlighted ? 'graph-edge-highlight' : 'graph-edge'}
                markerEnd={`url(#${isHighlighted ? 'arrow-hl-' : 'arrow-'}${gradientId})`}
                fill="none"
              />
              <text
                x={ctrlX}
                y={ctrlY - 6}
                textAnchor="middle"
                className={isHighlighted ? 'graph-edge-label-highlight' : 'graph-edge-label'}
              >
                {e.label}
              </text>
            </g>
          );
        })}

        {layout.nodes.map((pos) => {
          const node = nodeById.get(pos.id);
          if (!node) return null;
          const isHighlighted = highlightNodeIds?.has(pos.id) ?? false;
          const classes = ['graph-node', node.isAccept ? 'graph-node-accept' : '', isHighlighted ? 'graph-node-highlight' : '']
            .filter(Boolean)
            .join(' ');
          return (
            <g key={pos.id}>
              {node.isAccept && <circle cx={pos.x} cy={pos.y} r={NODE_RADIUS - 4} className="graph-node-ring" />}
              <circle cx={pos.x} cy={pos.y} r={NODE_RADIUS} className={classes} />
              <text x={pos.x} y={pos.y} textAnchor="middle" dominantBaseline="central" className="graph-node-label">
                {node.label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
