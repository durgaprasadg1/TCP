import { PageHeader, Term } from '../components/ui';
import { RegexWorkspace } from '../features/regex/RegexWorkspace';

export default function RegexLab() {
  return (
    <div>
      <PageHeader
        title="Regex Laboratory"
        subtitle={
          <>
            An educational <Term k="regex">regular expression</Term> → <Term k="nfa">NFA</Term> → <Term k="dfa">DFA</Term> visualizer and
            step-by-step simulator. A regex is compiled with <Term k="thompson">Thompson's construction</Term> and the{' '}
            <Term k="subsetConstruction">subset construction</Term>, then you can watch a test string being matched one character (and one{' '}
            <Term k="epsilonClosure">ε-closure</Term>) at a time. This laboratory runs its engine directly in the browser and never uses
            JavaScript's native <code>RegExp</code>.
          </>
        }
      />
      <RegexWorkspace />
    </div>
  );
}
