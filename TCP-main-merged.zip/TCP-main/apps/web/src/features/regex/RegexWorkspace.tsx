import { buildDfa, buildNfa, parseRegex, RegexSyntaxError, simulateDfa, simulateNfa } from '@cw/core/regex';
import type { Dfa, DfaTrace, Nfa, NfaTrace, RegexError } from '@cw/core/regex';
import { useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import { Card } from '../../components/ui';
import { cn } from '../../lib/cn';
import { dfaToGraph, nfaToGraph } from './graph/adapters';
import { GraphView } from './graph/GraphView';
import { ErrorPanel, ExampleRegexes, Legend, SimulationControls } from './RegexParts';
import { describeDfaStep, describeNfaStep, dfaHighlight, nfaHighlight } from './simulationView';

interface Compiled {
  pattern: string;
  nfa: Nfa;
  dfa: Dfa;
}

type SimMode = 'DFA' | 'NFA';

/**
 * Regex -> NFA -> DFA pipeline with a step-by-step simulator.
 * Everything is computed in the browser by the engine in `@cw/core/regex`; this component only holds UI state.
 */
export function RegexWorkspace() {
  const [pattern, setPattern] = useState('');
  const [compiled, setCompiled] = useState<Compiled | null>(null);
  const [buildError, setBuildError] = useState<RegexError | null>(null);

  const [simMode, setSimMode] = useState<SimMode>('DFA');
  const [testString, setTestString] = useState('');
  const [dfaTrace, setDfaTrace] = useState<DfaTrace | null>(null);
  const [nfaTrace, setNfaTrace] = useState<NfaTrace | null>(null);
  const [stepIndex, setStepIndex] = useState(0);
  const [isStepping, setIsStepping] = useState(false);

  const activeTrace = simMode === 'DFA' ? dfaTrace : nfaTrace;
  const accepted = activeTrace?.accepted ?? null;

  function resetSimulationState() {
    setDfaTrace(null);
    setNfaTrace(null);
    setStepIndex(0);
    setIsStepping(false);
  }

  function handleBuild(source: string) {
    setPattern(source);
    resetSimulationState();
    try {
      const ast = parseRegex(source);
      const nfa = buildNfa(ast);
      const dfa = buildDfa(nfa);
      setCompiled({ pattern: source, nfa, dfa });
      setBuildError(null);
    } catch (e) {
      if (e instanceof RegexSyntaxError) {
        setBuildError(e.regexError);
      } else {
        setBuildError({
          code: 'UNEXPECTED_TOKEN',
          message: e instanceof Error ? e.message : 'Unknown error while building automata.',
          position: 0,
        });
      }
      setCompiled(null);
    }
  }

  function handleSubmitBuild(e: FormEvent) {
    e.preventDefault();
    handleBuild(pattern);
  }

  function runTest() {
    if (!compiled) return;
    const dTrace = simulateDfa(compiled.dfa, testString);
    const nTrace = simulateNfa(compiled.nfa, testString);
    setDfaTrace(dTrace);
    setNfaTrace(nTrace);
    setStepIndex(0);
    setIsStepping(false);
  }

  function handleSubmitTest(e: FormEvent) {
    e.preventDefault();
    runTest();
  }

  function startSimulation() {
    if (!dfaTrace) runTest();
    setIsStepping(true);
    setStepIndex(0);
  }

  const totalSteps = activeTrace ? activeTrace.steps.length : 0;

  function next() {
    setStepIndex((i) => Math.min(i + 1, totalSteps - 1));
  }
  function previous() {
    setStepIndex((i) => Math.max(i - 1, 0));
  }
  function resetStepper() {
    setStepIndex(0);
  }

  const nfaGraph = useMemo(() => (compiled ? nfaToGraph(compiled.nfa) : null), [compiled]);
  const dfaGraph = useMemo(() => (compiled ? dfaToGraph(compiled.dfa) : null), [compiled]);

  const nfaHl = useMemo(() => {
    if (!compiled || !nfaTrace || !isStepping || simMode !== 'NFA') return null;
    return nfaHighlight(compiled.nfa, nfaTrace, Math.min(stepIndex, nfaTrace.steps.length - 1));
  }, [compiled, nfaTrace, isStepping, simMode, stepIndex]);

  const dfaHl = useMemo(() => {
    if (!dfaTrace || !isStepping || simMode !== 'DFA') return null;
    return dfaHighlight(dfaTrace, Math.min(stepIndex, dfaTrace.steps.length - 1));
  }, [dfaTrace, isStepping, simMode, stepIndex]);

  const currentStepDescription = useMemo(() => {
    if (!isStepping) return '';
    if (simMode === 'DFA') {
      return dfaTrace ? describeDfaStep(compiled?.dfa, dfaTrace, Math.min(stepIndex, dfaTrace.steps.length - 1)) : '';
    }
    return nfaTrace ? describeNfaStep(compiled?.nfa, nfaTrace, Math.min(stepIndex, nfaTrace.steps.length - 1)) : '';
  }, [isStepping, simMode, stepIndex, compiled, dfaTrace, nfaTrace]);

  return (
    <div className="space-y-4">
      <Card title="1. Enter a regex" headingId="build-heading">
        <form onSubmit={handleSubmitBuild} className="flex flex-wrap gap-2 max-[480px]:flex-col">
          <label htmlFor="regex-input" className="sr-only">
            Regex pattern
          </label>
          <input
            id="regex-input"
            type="text"
            value={pattern}
            onChange={(e) => setPattern(e.target.value)}
            placeholder="e.g. (a|b)*abb"
            className="input min-w-0 grow basis-[260px]"
            spellCheck={false}
            autoComplete="off"
          />
          <button type="submit" className="btn btn-primary max-[480px]:w-full">
            Build
          </button>
        </form>
        <p className="mt-3 text-xs text-slate-400">
          Supported: letters, digits, concatenation (implicit), alternation <code>|</code>, Kleene star <code>*</code>, and grouping{' '}
          <code>()</code>. No escaping, character classes, or other operators in this MVP.
        </p>
        {buildError && <ErrorPanel error={buildError} source={pattern} />}
        <ExampleRegexes onSelect={handleBuild} />
      </Card>

      {compiled && nfaGraph && dfaGraph && (
        <>
          <Card title="2. NFA (Thompson's construction)" headingId="nfa-heading">
            <GraphView
              nodes={nfaGraph.nodes}
              edges={nfaGraph.edges}
              startId={compiled.nfa.start}
              ariaLabel={`NFA graph for regex ${compiled.pattern}`}
              highlightNodeIds={nfaHl?.nodeIds}
              highlightEdgeKeys={nfaHl?.edgeKeys}
            />
          </Card>

          <Card title="3. DFA (subset construction)" headingId="dfa-heading">
            <GraphView
              nodes={dfaGraph.nodes}
              edges={dfaGraph.edges}
              startId={compiled.dfa.start}
              ariaLabel={`DFA graph for regex ${compiled.pattern}`}
              highlightNodeIds={dfaHl?.nodeIds}
              highlightEdgeKeys={dfaHl?.edgeKeys}
            />
            <Legend />
          </Card>

          <Card title="4. Test a string" headingId="test-heading">
            <p className="text-xs text-slate-400">
              Acceptance is decided by running the <strong>DFA</strong> over the whole string, one character at a time, and checking whether
              the final state is accepting once all input is consumed. Switch to NFA mode to see the same input tracked as a set of active
              states via epsilon-closures instead — both modes always agree on the accept/reject verdict.
            </p>

            <form onSubmit={handleSubmitTest} className="mt-3 flex flex-wrap gap-2 max-[480px]:flex-col">
              <label htmlFor="test-input" className="sr-only">
                Test string
              </label>
              <input
                id="test-input"
                type="text"
                value={testString}
                onChange={(e) => setTestString(e.target.value)}
                placeholder="e.g. aabb"
                className="input min-w-0 grow basis-[260px]"
                spellCheck={false}
                autoComplete="off"
              />
              <button type="submit" className="btn btn-primary max-[480px]:w-full">
                Test
              </button>
            </form>

            <fieldset className="mt-4 flex flex-wrap items-center gap-5 rounded-md border border-ink-600 px-4 py-2.5">
              <legend className="px-1.5 text-xs text-slate-400">Simulation mode</legend>
              <label className="flex items-center gap-1.5 text-sm text-slate-200">
                <input
                  type="radio"
                  name="simMode"
                  className="accent-accent"
                  checked={simMode === 'DFA'}
                  onChange={() => setSimMode('DFA')}
                />{' '}
                DFA (default)
              </label>
              <label className="flex items-center gap-1.5 text-sm text-slate-200">
                <input
                  type="radio"
                  name="simMode"
                  className="accent-accent"
                  checked={simMode === 'NFA'}
                  onChange={() => setSimMode('NFA')}
                />{' '}
                NFA (epsilon-closures)
              </label>
            </fieldset>

            {activeTrace && (
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <div
                  className={cn(
                    'rounded-md border px-3 py-1.5 text-base font-bold',
                    accepted ? 'border-ok/50 bg-ok/10 text-ok' : 'border-bad/50 bg-bad/10 text-bad',
                  )}
                  role="status"
                  aria-live="polite"
                >
                  {accepted ? '✔ Accepted' : '✘ Rejected'}
                  {dfaTrace?.hasOutOfAlphabetChar && simMode === 'DFA' && (
                    <span className="text-xs font-normal"> (contains a character outside the regex's alphabet)</span>
                  )}
                </div>
                <button type="button" className="btn btn-primary" onClick={startSimulation}>
                  {isStepping ? 'Restart step-by-step simulation' : 'Simulate step-by-step'}
                </button>
              </div>
            )}

            {isStepping && activeTrace && (
              <SimulationControls
                stepIndex={Math.min(stepIndex, totalSteps - 1)}
                totalSteps={totalSteps}
                inputLength={activeTrace.input.length}
                onNext={next}
                onPrevious={previous}
                onReset={resetStepper}
                currentDescription={currentStepDescription}
              />
            )}
          </Card>
        </>
      )}

      <p className="text-center text-xs text-slate-500">
        Regex Laboratory — custom regex engine; no use of JavaScript's native <code>RegExp</code> for parsing or matching.
      </p>
    </div>
  );
}
