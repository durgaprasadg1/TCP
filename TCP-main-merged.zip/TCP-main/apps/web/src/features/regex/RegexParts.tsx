import { REGEX_EXAMPLES } from '@cw/core/regex';
import type { RegexError } from '@cw/core/regex';

/** Structured regex error with a caret under the offending character. */
export function ErrorPanel({ error, source }: { error: RegexError; source: string }) {
  const caretLine = ' '.repeat(error.position) + '^';
  return (
    <div className="mt-4 rounded-md border border-bad/40 bg-bad/10 px-3 py-2 text-sm text-bad" role="alert">
      <p className="mb-2">
        <strong>{error.code.replace(/_/g, ' ')}:</strong> {error.message}
      </p>
      {source.length > 0 && (
        <pre className="overflow-x-auto text-xs" aria-hidden="true">
          {source}
          {'\n'}
          {caretLine}
        </pre>
      )}
    </div>
  );
}

/** One-click example regexes. */
export function ExampleRegexes({ onSelect }: { onSelect: (pattern: string) => void }) {
  return (
    <div className="mt-5">
      <h3 className="mb-2 text-sm font-semibold text-slate-200">Example regexes</h3>
      <ul className="flex flex-col gap-1.5">
        {REGEX_EXAMPLES.map((ex) => (
          <li key={ex.pattern} className="flex flex-wrap items-center gap-2.5">
            <button type="button" className="btn" onClick={() => onSelect(ex.pattern)} title={ex.description}>
              <code>{ex.pattern}</code>
            </button>
            <span className="text-xs text-slate-400">{ex.description}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Key to the graph symbols. Uses the same graph-* classes as GraphView so it always matches. */
export function Legend() {
  return (
    <div className="mt-4 flex flex-wrap gap-4 text-xs text-slate-400" aria-label="Graph legend">
      <div className="flex items-center gap-1.5">
        <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
          <circle cx="14" cy="14" r="11" className="graph-node" />
        </svg>
        <span>State</span>
      </div>
      <div className="flex items-center gap-1.5">
        <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
          <circle cx="14" cy="14" r="8" className="graph-node-ring" />
          <circle cx="14" cy="14" r="11" className="graph-node graph-node-accept" />
        </svg>
        <span>Accepting state (double circle)</span>
      </div>
      <div className="flex items-center gap-1.5">
        <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
          <line x1="2" y1="14" x2="22" y2="14" className="graph-edge" markerEnd="url(#legend-arrow)" />
          <defs>
            <marker id="legend-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" className="graph-arrowhead" />
            </marker>
          </defs>
        </svg>
        <span>Incoming arrow marks the start state</span>
      </div>
      <div className="flex items-center gap-1.5">
        <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
          <circle cx="14" cy="14" r="11" className="graph-node-highlight" />
        </svg>
        <span>Currently active during simulation</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="w-7 text-center font-mono font-bold text-slate-200">ε</span>
        <span>Epsilon (empty) transition — consumes no input</span>
      </div>
    </div>
  );
}

interface SimulationControlsProps {
  stepIndex: number;
  /** Number of steps = input.length + 1. */
  totalSteps: number;
  inputLength: number;
  onNext: () => void;
  onPrevious: () => void;
  onReset: () => void;
  currentDescription: string;
}

/** Next / Previous / Reset plus the live step counter, input position and step description. */
export function SimulationControls({
  stepIndex,
  totalSteps,
  inputLength,
  onNext,
  onPrevious,
  onReset,
  currentDescription,
}: SimulationControlsProps) {
  const isFirst = stepIndex === 0;
  const isLast = stepIndex === totalSteps - 1;

  return (
    <div className="mt-4 rounded-md border border-ink-600 bg-slate-950 px-3 py-3">
      <div className="mb-2.5 flex flex-wrap gap-2">
        <button type="button" className="btn" onClick={onPrevious} disabled={isFirst} aria-label="Previous step">
          ◀ Previous
        </button>
        <button type="button" className="btn" onClick={onReset} aria-label="Reset simulation">
          ⟲ Reset
        </button>
        <button type="button" className="btn" onClick={onNext} disabled={isLast} aria-label="Next step">
          Next ▶
        </button>
      </div>
      <div className="flex flex-wrap gap-4 text-xs text-slate-400" role="status" aria-live="polite">
        <span>
          Step <strong>{stepIndex}</strong> / {totalSteps - 1}
        </span>
        <span>
          Input position <strong>{stepIndex}</strong> / {inputLength}
        </span>
        <span className="basis-full font-mono text-sm text-slate-200">{currentDescription}</span>
      </div>
    </div>
  );
}
