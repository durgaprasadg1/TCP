import { describe, expect, it } from 'vitest';
import { parseRegex } from '../../src/regex/parser';
import { buildNfa } from '../../src/regex/nfa';
import { buildDfa } from '../../src/regex/dfa';
import { simulateDfa, simulateNfa, DEAD_STATE } from '../../src/regex/simulate';

function compile(re: string) {
  const ast = parseRegex(re);
  const nfa = buildNfa(ast);
  const dfa = buildDfa(nfa);
  return { nfa, dfa };
}

describe('simulateDfa - acceptance', () => {
  it('accepts strings matching the language', () => {
    const { dfa } = compile('(a|b)*abb');
    for (const s of ['abb', 'aabb', 'babb', 'aaabbabb']) {
      expect(simulateDfa(dfa, s).accepted).toBe(true);
    }
  });

  it('rejects strings not matching the language', () => {
    const { dfa } = compile('(a|b)*abb');
    for (const s of ['ab', 'abc', 'bba', 'aabbb']) {
      expect(simulateDfa(dfa, s).accepted).toBe(false);
    }
  });

  it('handles the empty input string', () => {
    const { dfa: starDfa } = compile('a*');
    expect(simulateDfa(starDfa, '').accepted).toBe(true); // zero repetitions is valid

    const { dfa: plainDfa } = compile('ab');
    expect(simulateDfa(plainDfa, '').accepted).toBe(false); // requires at least "ab"
  });

  it('rejects on a character outside the regex alphabet without throwing', () => {
    const { dfa } = compile('ab');
    const trace = simulateDfa(dfa, 'az');
    expect(trace.accepted).toBe(false);
    expect(trace.hasOutOfAlphabetChar).toBe(true);
    expect(trace.steps.at(-1)!.isDead).toBe(true);
    expect(trace.steps.at(-1)!.stateId).toBe(DEAD_STATE);
  });

  it('evaluates acceptance only after the full input is consumed', () => {
    const { dfa } = compile('abc');
    const trace = simulateDfa(dfa, 'ab');
    // 'ab' is a valid prefix but not accepted since 'c' hasn't been consumed
    expect(trace.accepted).toBe(false);
  });
});

describe('simulateDfa - step trace / boundary controls', () => {
  it('produces exactly input.length + 1 steps', () => {
    const { dfa } = compile('(a|b)*abb');
    const trace = simulateDfa(dfa, 'aabb');
    expect(trace.steps.length).toBe(5);
    expect(trace.steps[0]!.position).toBe(0);
    expect(trace.steps.at(-1)!.position).toBe(4);
  });

  it('step 0 has no consumedChar (Previous should be disabled here)', () => {
    const { dfa } = compile('ab');
    const trace = simulateDfa(dfa, 'ab');
    expect(trace.steps[0]!.consumedChar).toBeUndefined();
    expect(trace.steps[0]!.index).toBe(0);
  });

  it('final step index equals input length (Next should be disabled here)', () => {
    const { dfa } = compile('ab');
    const trace = simulateDfa(dfa, 'ab');
    expect(trace.steps.at(-1)!.index).toBe(trace.input.length);
  });

  it('step indices are contiguous and monotonically increasing', () => {
    const { dfa } = compile('(a|b)*abb');
    const trace = simulateDfa(dfa, 'aabb');
    trace.steps.forEach((step, i) => expect(step.index).toBe(i));
  });

  it('single-character input still has a well-defined first and last step', () => {
    const { dfa } = compile('a');
    const trace = simulateDfa(dfa, 'a');
    expect(trace.steps.length).toBe(2);
    expect(trace.steps[0]!.consumedChar).toBeUndefined();
    expect(trace.steps[1]!.consumedChar).toBe('a');
    expect(trace.accepted).toBe(true);
  });

  it('empty input produces exactly one step (start state only)', () => {
    const { dfa } = compile('a*');
    const trace = simulateDfa(dfa, '');
    expect(trace.steps.length).toBe(1);
    expect(trace.steps[0]!.index).toBe(0);
  });
});

describe('simulateNfa - epsilon closures & nondeterministic branching', () => {
  it('accepts/rejects consistently with the DFA for a nondeterministic regex', () => {
    const { nfa, dfa } = compile('a|ab');
    for (const s of ['a', 'ab', 'b', '', 'abc']) {
      expect(simulateNfa(nfa, s).accepted).toBe(simulateDfa(dfa, s).accepted);
    }
  });

  it('tracks multiple active states at once under branching', () => {
    const { nfa } = compile('a|ab');
    const trace = simulateNfa(nfa, 'a');
    // After consuming 'a', both the "a" branch's accept state and the
    // "ab" branch's mid-state should be active simultaneously.
    expect(trace.steps[1]!.states.length).toBeGreaterThan(1);
  });

  it('handles empty string via epsilon-closure of the start state alone', () => {
    const { nfa } = compile('a*');
    const trace = simulateNfa(nfa, '');
    expect(trace.accepted).toBe(true);
    expect(trace.steps.length).toBe(1);
  });
});
