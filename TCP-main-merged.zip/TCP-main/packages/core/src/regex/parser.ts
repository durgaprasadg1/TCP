import type { AstNode } from './ast';
import { makeError } from './errors';
import { tokenize, type Token } from './lexer';

/**
 * Recursive-descent parser.
 *
 *   union   := concat ('|' concat)*
 *   concat  := star+
 *   star    := atom '*'*
 *   atom    := CHAR | '(' union ')'
 *
 * Empty-string behavior: this MVP has no epsilon literal. The overall
 * regex must not be empty, and `()` (an empty group) is rejected as a
 * structured error rather than silently treated as epsilon.
 */
class Parser {
  private tokens: Token[];
  private pos = 0;

  constructor(tokens: Token[]) {
    this.tokens = tokens;
  }

  // The token stream always ends with EOF and the parser never consumes it,
  // so `pos` always points at a real token.
  private peek(): Token {
    return this.tokens[this.pos] as Token;
  }

  private advance(): Token {
    const t = this.tokens[this.pos] as Token;
    this.pos++;
    return t;
  }

  parseRegex(source: string): AstNode {
    if (this.peek().type === 'EOF') {
      throw makeError('EMPTY_REGEX', 'Regex cannot be empty. Enter at least one literal character.', 0);
    }
    const node = this.parseUnion();
    if (this.peek().type !== 'EOF') {
      const t = this.peek();
      if (t.type === 'RPAREN') {
        throw makeError('UNBALANCED_PAREN_CLOSE', `Unmatched ')' at position ${t.position}: no corresponding '(' was opened.`, t.position);
      }
      throw makeError(
        'TRAILING_INPUT',
        `Unexpected '${t.value}' at position ${t.position}. Did you forget an operator between expressions?`,
        t.position,
      );
    }
    void source;
    return node;
  }

  private parseUnion(): AstNode {
    let left = this.parseConcat();
    while (this.peek().type === 'PIPE') {
      const pipeToken = this.advance();
      // Right operand of '|' must exist and must not itself start with
      // another '|' or be immediately followed by ')' / EOF.
      if (this.peek().type === 'PIPE' || this.peek().type === 'RPAREN' || this.peek().type === 'EOF') {
        throw makeError('DANGLING_OPERATOR', `'|' at position ${pipeToken.position} is missing a right-hand operand.`, pipeToken.position);
      }
      const right = this.parseConcat();
      left = { type: 'Union', left, right };
    }
    return left;
  }

  private startsAtom(): boolean {
    const t = this.peek().type;
    return t === 'CHAR' || t === 'LPAREN';
  }

  private parseConcat(): AstNode {
    // At least one star-term is required by the caller's context
    // (parseUnion always calls this right after '|' or at the start,
    // both of which guarantee an atom must follow).
    let left = this.parseStar();
    while (this.startsAtom()) {
      const right = this.parseStar();
      left = { type: 'Concat', left, right };
    }
    return left;
  }

  private parseStar(): AstNode {
    let node = this.parseAtom();
    while (this.peek().type === 'STAR') {
      this.advance();
      node = { type: 'Star', child: node };
    }
    return node;
  }

  private parseAtom(): AstNode {
    const t = this.peek();

    if (t.type === 'CHAR') {
      this.advance();
      return { type: 'Literal', value: t.value, position: t.position };
    }

    if (t.type === 'LPAREN') {
      const openToken = this.advance();
      if (this.peek().type === 'RPAREN') {
        throw makeError(
          'EMPTY_GROUP',
          `Empty group '()' at position ${openToken.position} is not supported (no epsilon literal in this MVP).`,
          openToken.position,
        );
      }
      const inner = this.parseUnion();
      if (this.peek().type !== 'RPAREN') {
        throw makeError(
          'UNBALANCED_PAREN_OPEN',
          `Unbalanced '(' opened at position ${openToken.position}: missing a matching ')'.`,
          openToken.position,
        );
      }
      this.advance(); // consume ')'
      return inner;
    }

    if (t.type === 'STAR') {
      throw makeError('DANGLING_OPERATOR', `'*' at position ${t.position} has no preceding character or group to repeat.`, t.position);
    }

    if (t.type === 'RPAREN') {
      throw makeError('UNBALANCED_PAREN_CLOSE', `Unmatched ')' at position ${t.position}: no corresponding '(' was opened.`, t.position);
    }

    if (t.type === 'PIPE') {
      throw makeError('DANGLING_OPERATOR', `'|' at position ${t.position} is missing a left-hand operand.`, t.position);
    }

    // EOF reaching here means an operator/paren was expecting
    // an operand that never arrived.
    throw makeError('UNEXPECTED_TOKEN', `Unexpected end of input at position ${t.position}; expected a letter, digit, or '('.`, t.position);
  }
}

export function parseRegex(source: string): AstNode {
  const tokens = tokenize(source);
  const parser = new Parser(tokens);
  return parser.parseRegex(source);
}
