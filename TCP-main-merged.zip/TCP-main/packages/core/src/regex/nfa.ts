import { EPSILON } from '../shared-types';
import type { AstNode } from './ast';

/**
 * Epsilon transition symbol, distinct from any literal (letters/digits only).
 * Shared with the PDA/TM engines (see shared-types); re-exported for convenience.
 */
export { EPSILON };

export type StateId = number;

export interface NfaTransition {
  from: StateId;
  /** EPSILON or a single literal character. */
  symbol: string;
  to: StateId;
}

export interface Nfa {
  states: StateId[];
  start: StateId;
  /** Exactly one accept state (Thompson's construction invariant). */
  accept: StateId;
  transitions: NfaTransition[];
  /** For readability in the UI, e.g. "q0". */
  stateLabel: (id: StateId) => string;
}

interface Fragment {
  start: StateId;
  accept: StateId;
}

/**
 * Builds an NFA from an AST using Thompson's construction.
 * State IDs are assigned deterministically via a monotonically
 * increasing counter, in a fixed (left-to-right, post-order-ish) walk
 * of the AST, so the same regex always yields the same numbering.
 */
export function buildNfa(ast: AstNode): Nfa {
  let nextId = 0;
  const transitions: NfaTransition[] = [];
  const states: StateId[] = [];

  function newState(): StateId {
    const id = nextId++;
    states.push(id);
    return id;
  }

  function addTransition(from: StateId, symbol: string, to: StateId): void {
    transitions.push({ from, symbol, to });
  }

  function build(node: AstNode): Fragment {
    switch (node.type) {
      case 'Literal': {
        const start = newState();
        const accept = newState();
        addTransition(start, node.value, accept);
        return { start, accept };
      }
      case 'Concat': {
        const left = build(node.left);
        const right = build(node.right);
        addTransition(left.accept, EPSILON, right.start);
        return { start: left.start, accept: right.accept };
      }
      case 'Union': {
        const left = build(node.left);
        const right = build(node.right);
        const start = newState();
        const accept = newState();
        addTransition(start, EPSILON, left.start);
        addTransition(start, EPSILON, right.start);
        addTransition(left.accept, EPSILON, accept);
        addTransition(right.accept, EPSILON, accept);
        return { start, accept };
      }
      case 'Star': {
        const inner = build(node.child);
        const start = newState();
        const accept = newState();
        addTransition(start, EPSILON, inner.start);
        addTransition(start, EPSILON, accept);
        addTransition(inner.accept, EPSILON, inner.start);
        addTransition(inner.accept, EPSILON, accept);
        return { start, accept };
      }
    }
  }

  const frag = build(ast);

  return {
    states,
    start: frag.start,
    accept: frag.accept,
    transitions,
    stateLabel: (id) => `q${id}`,
  };
}

/** Epsilon-closure of a set of NFA states. */
export function epsilonClosure(nfa: Nfa, stateSet: Iterable<StateId>): Set<StateId> {
  const closure = new Set<StateId>(stateSet);
  const stack: StateId[] = [...closure];
  while (stack.length > 0) {
    const s = stack.pop()!;
    for (const t of nfa.transitions) {
      if (t.from === s && t.symbol === EPSILON && !closure.has(t.to)) {
        closure.add(t.to);
        stack.push(t.to);
      }
    }
  }
  return closure;
}

/** All states reachable from `stateSet` by consuming a single literal `symbol`. */
export function move(nfa: Nfa, stateSet: Iterable<StateId>, symbol: string): Set<StateId> {
  const result = new Set<StateId>();
  const stateSetArr = new Set(stateSet);
  for (const t of nfa.transitions) {
    if (stateSetArr.has(t.from) && t.symbol === symbol) {
      result.add(t.to);
    }
  }
  return result;
}

/** The literal alphabet used by an NFA (excludes epsilon). */
export function nfaAlphabet(nfa: Nfa): string[] {
  const symbols = new Set<string>();
  for (const t of nfa.transitions) {
    if (t.symbol !== EPSILON) symbols.add(t.symbol);
  }
  return [...symbols].sort();
}
