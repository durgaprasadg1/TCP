import { EPSILON } from '@cw/core/regex';
import type { Dfa, DfaTrace, Nfa, NfaTrace } from '@cw/core/regex';

/** Nodes and edges ("from->to") the graph should draw as active at one simulation step. */
export interface GraphHighlight {
  nodeIds: Set<number>;
  edgeKeys: Set<string>;
}

/** DFA: the single current state, plus the edge taken to reach it from the previous step. */
export function dfaHighlight(trace: DfaTrace, stepIndex: number): GraphHighlight {
  const nodeIds = new Set<number>();
  const edgeKeys = new Set<string>();
  const step = trace.steps[stepIndex];
  if (!step) return { nodeIds, edgeKeys };
  if (!step.isDead) nodeIds.add(step.stateId);
  if (stepIndex > 0) {
    const prev = trace.steps[stepIndex - 1];
    if (prev && !prev.isDead && !step.isDead) {
      edgeKeys.add(`${prev.stateId}->${step.stateId}`);
    }
  }
  return { nodeIds, edgeKeys };
}

/** NFA: the whole ε-closed set of active states, the ε-edges inside it, and the edges consumed to get here. */
export function nfaHighlight(nfa: Nfa, trace: NfaTrace, stepIndex: number): GraphHighlight {
  const step = trace.steps[stepIndex];
  const nodeIds = new Set<number>(step?.states ?? []);
  const edgeKeys = new Set<string>();
  if (!step) return { nodeIds, edgeKeys };

  // Epsilon edges internal to the current closure (explains the fan-out).
  for (const t of nfa.transitions) {
    if (t.symbol === EPSILON && nodeIds.has(t.from) && nodeIds.has(t.to)) {
      edgeKeys.add(`${t.from}->${t.to}`);
    }
  }
  // Edges consumed to arrive here from the previous step.
  if (stepIndex > 0) {
    const prevStates = new Set(trace.steps[stepIndex - 1]?.states ?? []);
    const symbol = step.consumedChar;
    for (const t of nfa.transitions) {
      if (t.symbol === symbol && prevStates.has(t.from) && nodeIds.has(t.to)) {
        edgeKeys.add(`${t.from}->${t.to}`);
      }
    }
  }
  return { nodeIds, edgeKeys };
}

/** One-line explanation of a DFA step, shown under the stepper controls. */
export function describeDfaStep(dfa: Dfa | undefined, trace: DfaTrace, stepIndex: number): string {
  const step = trace.steps[stepIndex];
  if (!step) return '';
  if (step.isDead) {
    return `No transition available — in an implicit dead state (input is rejected).`;
  }
  const label = dfa?.stateLabel(step.stateId) ?? `state ${step.stateId}`;
  return step.consumedChar ? `Consumed '${step.consumedChar}' → now in ${label}.` : `Start state: ${label}.`;
}

/** One-line explanation of an NFA step, shown under the stepper controls. */
export function describeNfaStep(nfa: Nfa | undefined, trace: NfaTrace, stepIndex: number): string {
  const step = trace.steps[stepIndex];
  if (!step) return '';
  const labels = step.states.map((id) => nfa?.stateLabel(id) ?? `q${id}`);
  return step.consumedChar
    ? `Consumed '${step.consumedChar}' → active states: {${labels.join(', ')}}`
    : `Start: epsilon-closure = {${labels.join(', ')}}`;
}
