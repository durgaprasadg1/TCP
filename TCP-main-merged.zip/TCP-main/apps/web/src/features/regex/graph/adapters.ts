import type { Dfa, Nfa } from '@cw/core/regex';
import type { GraphEdgeInput, GraphNodeInput } from './GraphView';

export function nfaToGraph(nfa: Nfa): { nodes: GraphNodeInput[]; edges: GraphEdgeInput[] } {
  const nodes: GraphNodeInput[] = nfa.states.map((id) => ({
    id,
    label: nfa.stateLabel(id),
    isStart: id === nfa.start,
    isAccept: id === nfa.accept,
  }));
  const edges: GraphEdgeInput[] = nfa.transitions.map((t) => ({
    from: t.from,
    to: t.to,
    label: t.symbol,
    isEpsilon: t.symbol === 'ε',
  }));
  return { nodes, edges };
}

export function dfaToGraph(dfa: Dfa): { nodes: GraphNodeInput[]; edges: GraphEdgeInput[] } {
  const nodes: GraphNodeInput[] = dfa.states.map((s) => ({
    id: s.id,
    label: dfa.stateLabel(s.id),
    isStart: s.id === dfa.start,
    isAccept: s.isAccept,
  }));
  const edges: GraphEdgeInput[] = dfa.transitions.map((t) => ({
    from: t.from,
    to: t.to,
    label: t.symbol,
  }));
  return { nodes, edges };
}
