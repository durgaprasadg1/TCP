import { describe, expect, it } from 'vitest';
import type { AstNode } from '../../src/regex/ast';
import { RegexSyntaxError } from '../../src/regex/errors';
import { parseRegex } from '../../src/regex/parser';

/** Canonical fully-parenthesized stringification, for precedence assertions. */
function astToString(node: AstNode): string {
  switch (node.type) {
    case 'Literal':
      return node.value;
    case 'Concat':
      return `(${astToString(node.left)}.${astToString(node.right)})`;
    case 'Union':
      return `(${astToString(node.left)}|${astToString(node.right)})`;
    case 'Star':
      return `(${astToString(node.child)})*`;
  }
}

describe('parseRegex - precedence & structure', () => {
  it('parses a single literal', () => {
    expect(astToString(parseRegex('a'))).toBe('a');
  });

  it('parses implicit concatenation left-associatively', () => {
    expect(astToString(parseRegex('abc'))).toBe('((a.b).c)');
  });

  it('star binds tighter than concatenation', () => {
    // ab* means a(b*), not (ab)*
    expect(astToString(parseRegex('ab*'))).toBe('(a.(b)*)');
  });

  it('concatenation binds tighter than union', () => {
    // ab|cd means (ab)|(cd)
    expect(astToString(parseRegex('ab|cd'))).toBe('((a.b)|(c.d))');
  });

  it('parentheses override precedence for concat vs star', () => {
    expect(astToString(parseRegex('(ab)*'))).toBe('((a.b))*');
  });

  it('parentheses override precedence for union vs concat', () => {
    expect(astToString(parseRegex('a(b|c)d'))).toBe('((a.(b|c)).d)');
  });

  it('union is left-associative across multiple alternatives', () => {
    expect(astToString(parseRegex('a|b|c'))).toBe('((a|b)|c)');
  });

  it('multiple stars stack', () => {
    expect(astToString(parseRegex('a**'))).toBe('((a)*)*');
  });

  it('nested groups with stars and unions', () => {
    expect(astToString(parseRegex('(a|b)*c'))).toBe('(((a|b))*.c)');
  });
});

describe('parseRegex - errors', () => {
  function expectError(source: string, code: string) {
    try {
      parseRegex(source);
      expect.unreachable(`expected ${source} to throw`);
    } catch (e) {
      expect(e).toBeInstanceOf(RegexSyntaxError);
      expect((e as RegexSyntaxError).regexError.code).toBe(code);
    }
  }

  it('rejects empty regex', () => {
    expectError('', 'EMPTY_REGEX');
  });

  it('rejects dangling star', () => {
    expectError('*a', 'DANGLING_OPERATOR');
  });

  it('rejects dangling pipe (trailing)', () => {
    expectError('a|', 'DANGLING_OPERATOR');
  });

  it('rejects dangling pipe (leading)', () => {
    expectError('|a', 'DANGLING_OPERATOR');
  });

  it('rejects unbalanced open paren', () => {
    expectError('(a', 'UNBALANCED_PAREN_OPEN');
  });

  it('rejects unbalanced close paren', () => {
    expectError('a)', 'UNBALANCED_PAREN_CLOSE');
  });

  it('rejects empty group', () => {
    expectError('()', 'EMPTY_GROUP');
  });

  it('rejects trailing garbage after a valid expression', () => {
    expectError('a)b', 'UNBALANCED_PAREN_CLOSE');
  });
});
