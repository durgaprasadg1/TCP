/**
 * AST node types.
 *
 * Grammar (precedence low -> high): Union | Concat | Star | Atom
 *
 *   union   := concat ('|' concat)*
 *   concat  := star+                     (implicit concatenation)
 *   star    := atom '*'*                 (postfix, left-associative)
 *   atom    := CHAR | '(' union ')'
 *
 * `*` binds tightest, then concatenation, then `|` binds loosest.
 * Concatenation is explicit in the AST (a `Concat` node) even though
 * it has no surface-syntax symbol.
 */
export type AstNode = Literal | Concat | Union | Star;

export interface Literal {
  type: 'Literal';
  value: string;
  position: number;
}

export interface Concat {
  type: 'Concat';
  left: AstNode;
  right: AstNode;
}

export interface Union {
  type: 'Union';
  left: AstNode;
  right: AstNode;
}

export interface Star {
  type: 'Star';
  child: AstNode;
}
