export interface RegexExample {
  pattern: string;
  description: string;
  accept: string[];
  reject: string[];
}

export const REGEX_EXAMPLES: RegexExample[] = [
  {
    pattern: 'ab*',
    description: "'a' followed by zero or more 'b's",
    accept: ['a', 'ab', 'abbb'],
    reject: ['b', 'ba', ''],
  },
  {
    pattern: 'a|b',
    description: "Either 'a' or 'b'",
    accept: ['a', 'b'],
    reject: ['ab', '', 'c'],
  },
  {
    pattern: '(a|b)*abb',
    description: "Any mix of a/b, ending in 'abb' (classic textbook example)",
    accept: ['abb', 'aabb', 'babb', 'aaabbabb'],
    reject: ['ab', 'abbb', 'aab'],
  },
  {
    pattern: 'a*b*',
    description: "Zero or more 'a's followed by zero or more 'b's",
    accept: ['', 'aaa', 'bbb', 'aabb'],
    reject: ['ba', 'aba'],
  },
  {
    pattern: '(ab)*',
    description: "Zero or more repetitions of the exact pair 'ab'",
    accept: ['', 'ab', 'abab', 'ababab'],
    reject: ['a', 'aab', 'abb'],
  },
  {
    pattern: '1(0|1)*',
    description: 'Binary strings starting with 1 (no leading zero)',
    accept: ['1', '10', '111', '1001'],
    reject: ['0', '01', ''],
  },
];
